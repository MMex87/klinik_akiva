-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 26 Feb 2022 pada 18.55
-- Versi server: 10.4.21-MariaDB
-- Versi PHP: 8.0.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `klinik_akiva`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `diagnosa`
--

CREATE TABLE `diagnosa` (
  `id_diagnosa` int(11) NOT NULL,
  `s` text NOT NULL,
  `o` text NOT NULL,
  `a` text NOT NULL,
  `p` text NOT NULL,
  `jumlah` varchar(10) NOT NULL,
  `status` varchar(5) NOT NULL,
  `id_pendaftaran` int(5) NOT NULL,
  `id_icd` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `diagnosa`
--

INSERT INTO `diagnosa` (`id_diagnosa`, `s`, `o`, `a`, `p`, `jumlah`, `status`, `id_pendaftaran`, `id_icd`) VALUES
(4, 'Nyambek KINTIL', 'Nyambek ASU', 'Febris', 'konidin', '10', '0', 18, 1),
(7, 'anjim', 'bgt', 'CHF', 'paracetamol', '10', '0', 19, 1),
(8, 'sakit gigi', 'KOPIT', 'DM Insulin', 'paracetamol', '5', '0', 20, 2),
(9, 'sakit gigi', 'KOPIT', 'ISPA', 'konidin', '2', '0', 20, 3),
(10, 'omicron', 'kopit', 'DM Insulin', 'paracetamol', '5', '0', 21, 4),
(11, 'omicron', 'kopit', 'ISPA', 'konidin', '23', '0', 21, 5),
(12, 'omicron', 'kopit', 'DM Insulin', 'konimax', '3', '0', 21, 6),
(13, 'sdfs', 'wsfgjasok', 'DM non Insulin', 'konimax', '20', '0', 22, 7),
(14, 'fdfsw', 'wdkfghqas', 'DM non Insulin', 'konimax', '5', '0', 23, 8),
(15, 'fdfsw', 'wdkfghqas', 'LVA', 'paracetamol', '50', '0', 23, 9),
(16, 'shjfgj', 'klhdgsfoj', 'CHF', 'paracetamol', '20', '0', 24, 10),
(17, 'shjfgj', 'klhdgsfoj', 'DM non Insulin', 'konidin', '8', '0', 24, 11),
(18, 'ed sfd', 'hsdfyuru', 'DM non Insulin', 'paracetamol', '20', '0', 25, 12),
(19, 'ed sfd', 'hsdfyuru', 'ISPA', 'konidin', '20', '0', 25, 13),
(20, 'efjghioedghj', 'okefhjgosidhjgopwdsfgh', 'Febris', 'paracetamol', '50', '0', 26, 14),
(21, 'efjghioedghj', 'okefhjgosidhjgopwdsfgh', 'Headache', 'konidin', '30', '0', 26, 15),
(22, 'ytpeoyjkopdt', 'pjgopsdihgjoipdtjg', 'OA', 'konimax', '3', '0', 27, 16),
(24, 'ytpeoyjkopdt', 'pjgopsdihgjoipdtjg', 'GASTRITIS', 'GPU', '4', '0', 27, 17),
(25, 'yhjrdfj', 'ftyuedryu', 'ISPA', 'GPU', '3', '0', 28, 18),
(26, 'yhjrdfj', 'ftyuedryu', 'A00', 'diapet', '3', '0', 28, 19),
(27, 'ghuifghsdkj', 'kjlsdhfakfh', 'DM Insulin', 'sanmol', '3', '0', 29, 20),
(28, 'ghuifghsdkj', 'kjlsdhfakfh', 'A00', 'ultraflu', '2', '0', 29, 21),
(61, 'dfdf', 'fdfdf', 'A00', 'diapet', '3', '0', 33, 0),
(62, 'lsdfkjsola', 'ldksjfgaklf', 'A15', 'Paracetamol', '2', '0', 38, 2),
(63, 'lsdfkjsola', 'ldksjfgaklf', 'A92', 'konidin', '4', '0', 38, 10),
(64, '', '', 'C00', 'panadol', '2', '0', 39, 22),
(65, '', '', 'A09', 'mixagrip', '3', '0', 39, 1),
(67, '', '', 'A00', 'GPU', '3', '0', 39, 0),
(68, '', '', 'A00', 'sanmol', '7', '0', 39, 0),
(69, '', '', 'G00', 'diapet', '2', '0', 39, 65),
(70, '', '', 'G10', 'gazero', '2', '0', 39, 66),
(71, '', '', 'G09', 'remacil', '3', '0', 39, 65),
(74, 'asu', 'GCS: nyambek; Tensi: koyok; NACL: asu; Respirasi Rate: nyimbek; Suhu: seperti; Pemeriksaan Penunjang: anjing; GNS: nyombek; AU: suka; Choresterol: ngentoy dan; Lain-Lain: colskay', 'A64', 'remacil', '2', '0', 40, 5),
(79, '.mvbnsdcjkfg', 'fgjklhsejklgh;DKFGHSKLFGHJ;KSFJLHGL;FKJHGSLGwfkgheljkg;fjkdlghdflghjq;fhbgdfslghj;fkdhjgdl;efklgjhsfkgj;wflkgjhsfg;wfkgheodgf', 'A20', 'Antimo', '5', '0', 41, 3),
(80, 'gfg', 'tyt;tetw;etyety;ertyey;tytytre;eytw;etuyw;ytey;teyetye;yrtye', 'S29', 'gpu', '3', '0', 42, 199),
(85, 'dfafsd', 'ertyw;etwet;ertwet;ewtwe;ewte;retwe;terwtr;etert;ertwe;etwert', 'A15', 'Antimo', '4', '0', 43, 2),
(86, '', '', 'D10', 'konidin', '3', '0', 43, 38),
(87, 'fjslj', 'klajfklj;jlskdfjlk;lkjfalskfj;sklfdjlaf;fdmlkmcws;dklarjeirn;kdjfmdlf;dklfsdmlakj;ksdjfmklxn;kwdjtownrt', 'A09', 'Antimo', '2', '0', 44, 1),
(88, '', '', 'C00', 'konidin', '4', '0', 44, 22),
(89, '', '', '', 'gpu', '1', '0', 44, 0),
(90, 'sfga', 'ryrt;dtfed;fgwrtg;grg;ghthd;eheh;ghdh;dgheg;fgeg;edth', 'D00', 'gpu', '2', '0', 45, 37),
(91, '', '', 'A15', 'Antimo', '2', '0', 45, 2),
(92, 'fdggsd', 'jryhedg;rerdf;tryert;trwet;wrtert;fhdshgsd;gdfsgdhj;dgdfg;wertw4t;', 'L08', 'konidin', '3', '0', 46, 121),
(93, '', '', 'P35', 'gpu', '2', '0', 46, 167),
(94, '', '', '', 'Antimo', '3', '0', 46, 0),
(95, 'gsrh', 'etert;tetg;dsgsdg;rtret;eysd;edrtre;etedg;rtertg;ertet;terte', 'D00', 'Antimo', '3', '0', 47, 37),
(96, '', '', 'E07', 'gpu', '4', '0', 47, 46),
(117, '', '', 'D10', 'Antimo', '1', '0', 49, 38),
(118, '', '', 'S09', 'Antimo', '2', '0', 49, 197),
(119, 'ddgfg', 'trrt;fgd;rtr;gdfsg;sdfgd;dfgdg;dhdgh;fgdfg;dhetd;tert', 'D09', '', '', '0', 50, 37),
(123, 'dfsg', 'ewr;dfgsdf;fgstrt;wrfsrt;sftsgryq;fsgsrt;sdft;sdfsggwry;fgsrt;sfgtey', 'D09', 'konidin', '3', '0', 51, 37),
(124, 'dgdgrtrwy', 'ryertt;efkgjik;tsfklgklu;jflgkj;tsflkjgispo;dfgjkl;fgujdg;dfkgjirtj;fklgjdu;fkgjosg', 'R00', 'gpu', '2', '0', 52, 184),
(125, 'fretert', 'fsdtwkrf;hskljfwo;jkljfgsi;kjsdklgj;rjlkdfjoas;flsgjowd;fjlsdjufgiower;jlskfgjwr;kjsiofgjoqe;jwogfjw', 'L10', 'konidin', '3', '0', 55, 122),
(126, '', '', 'F09', 'Antimo', '3', '0', 55, 54),
(127, 'efwtyr', 'terfte;tedrg;terted;tdst;ertert;fdgs;rtets;fdsgs;rtsdg;rter', 'L30', '', '', '0', 53, 123),
(128, 'sfdgas', 'fgs;fdy;DFYGST;GYDRTY;ghfhety;hfdyet;hfhdh;hdhgdg;ghfhj;hfyeye', '', '', '', '0', 56, 0),
(129, 'sfgst', 'fgst;tsdfq;rgg;fdgg;efy;fgsd;efst;fgst;efyey;fg', 'S00', 'Antimo', '2', '0', 57, 197),
(130, 'dfhth', 'teu;ryy;ertuety;guedy;rgyef;fgs;fh;dfghsy;sdfgsh;sfhes', 'S00', 'gazero', '3', '0', 58, 197);

-- --------------------------------------------------------

--
-- Struktur dari tabel `icd_10`
--

CREATE TABLE `icd_10` (
  `id_icd` int(11) NOT NULL,
  `code1` varchar(10) DEFAULT NULL,
  `code2` varchar(10) DEFAULT NULL,
  `code3` int(10) DEFAULT NULL,
  `code4` varchar(250) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `icd_10`
--

INSERT INTO `icd_10` (`id_icd`, `code1`, `code2`, `code3`, `code4`) VALUES
(0, NULL, NULL, NULL, NULL),
(1, 'A00', 'A09', 1, 'Intestinal infectious diseases\r'),
(2, 'A15', 'A19', 1, 'Tuberculosis\r'),
(3, 'A20', 'A28', 1, 'Certain zoonotic bacterial diseases\r'),
(4, 'A30', 'A49', 1, 'Other bacterial diseases\r'),
(5, 'A50', 'A64', 1, 'Infections with a predominantly sexual mode of transmission\r'),
(6, 'A65', 'A69', 1, 'Other spirochaetal diseases\r'),
(7, 'A70', 'A74', 1, 'Other diseases caused by chlamydiae\r'),
(8, 'A75', 'A79', 1, 'Rickettsioses\r'),
(9, 'A80', 'A89', 1, 'Viral infections of the central nervous system\r'),
(10, 'A92', 'A99', 1, 'Arthropod-borne viral fevers and viral haemorrhagic fevers\r'),
(11, 'B00', 'B09', 1, 'Viral infections characterized by skin and mucous membrane lesions\r'),
(12, 'B15', 'B19', 1, 'Viral hepatitis\r'),
(13, 'B20', 'B24', 1, 'Human immunodeficiency virus [HIV] disease\r'),
(14, 'B25', 'B34', 1, 'Other viral diseases\r'),
(15, 'B35', 'B49', 1, 'Mycoses\r'),
(16, 'B50', 'B64', 1, 'Protozoal diseases\r'),
(17, 'B65', 'B83', 1, 'Helminthiases\r'),
(18, 'B85', 'B89', 1, 'Pediculosis, acariasis and other infestations\r'),
(19, 'B90', 'B94', 1, 'Sequelae of infectious and parasitic diseases\r'),
(20, 'B95', 'B98', 1, 'Bacterial, viral and other infectious agents\r'),
(21, 'B99', 'B99', 1, 'Other infectious diseases\r'),
(22, 'C00', 'C14', 2, 'Malignant neoplasms of lip, oral cavity and pharynx\r'),
(23, 'C15', 'C26', 2, 'Malignant neoplasms of digestive organs\r'),
(24, 'C30', 'C39', 2, 'Malignant neoplasms of respiratory and intrathoracic organs\r'),
(25, 'C40', 'C41', 2, 'Malignant neoplasms of bone and articular cartilage\r'),
(26, 'C43', 'C44', 2, 'Melanoma and other malignant neoplasms of skin\r'),
(27, 'C45', 'C49', 2, 'Malignant neoplasms of mesothelial and soft tissue\r'),
(28, 'C50', 'C50', 2, 'Malignant neoplasm of breast\r'),
(29, 'C51', 'C58', 2, 'Malignant neoplasms of female genital organs\r'),
(30, 'C60', 'C63', 2, 'Malignant neoplasms of male genital organs\r'),
(31, 'C64', 'C68', 2, 'Malignant neoplasms of urinary tract\r'),
(32, 'C69', 'C72', 2, 'Malignant neoplasms of eye, brain and other parts of central nervous system\r'),
(33, 'C73', 'C75', 2, 'Malignant neoplasms of thyroid and other endocrine glands\r'),
(34, 'C76', 'C80', 2, 'Malignant neoplasms of ill-defined, secondary and unspecified sites\r'),
(35, 'C81', 'C96', 2, 'Malignant neoplasms, stated or presumed to be primary, of lymphoid, haematopoietic and related tissue\r'),
(36, 'C97', 'C97', 2, 'Malignant neoplasms of independent (primary) multiple sites\r'),
(37, 'D00', 'D09', 2, 'In situ neoplasms\r'),
(38, 'D10', 'D36', 2, 'Benign neoplasms\r'),
(39, 'D37', 'D48', 2, 'Neoplasms of uncertain or unknown behaviour\r'),
(40, 'D50', 'D53', 3, 'Nutritional anaemias\r'),
(41, 'D55', 'D59', 3, 'Haemolytic anaemias\r'),
(42, 'D60', 'D64', 3, 'Aplastic and other anaemias\r'),
(43, 'D65', 'D69', 3, 'Coagulation defects, purpura and other haemorrhagic conditions\r'),
(44, 'D70', 'D77', 3, 'Other diseases of blood and blood-forming organs\r'),
(45, 'D80', 'D89', 3, 'Certain disorders involving the immune mechanism\r'),
(46, 'E00', 'E07', 4, 'Disorders of thyroid gland\r'),
(47, 'E10', 'E14', 4, 'Diabetes mellitus\r'),
(48, 'E15', 'E16', 4, 'Other disorders of glucose regulation and pancreatic internal secretion\r'),
(49, 'E20', 'E35', 4, 'Disorders of other endocrine glands\r'),
(50, 'E40', 'E46', 4, 'Malnutrition\r'),
(51, 'E50', 'E64', 4, 'Other nutritional deficiencies\r'),
(52, 'E65', 'E68', 4, 'Obesity and other hyperalimentation\r'),
(53, 'E70', 'E90', 4, 'Metabolic disorders\r'),
(54, 'F00', 'F09', 5, 'Organic, including symptomatic, mental disorders\r'),
(55, 'F10', 'F19', 5, 'Mental and behavioural disorders due to psychoactive substance use\r'),
(56, 'F20', 'F29', 5, 'Schizophrenia, schizotypal and delusional disorders\r'),
(57, 'F30', 'F39', 5, 'Mood [affective] disorders\r'),
(58, 'F40', 'F48', 5, 'Neurotic, stress-related and somatoform disorders\r'),
(59, 'F50', 'F59', 5, 'Behavioural syndromes associated with physiological disturbances and physical factors\r'),
(60, 'F60', 'F69', 5, 'Disorders of adult personality and behaviour\r'),
(61, 'F70', 'F79', 5, 'Mental retardation\r'),
(62, 'F80', 'F89', 5, 'Disorders of psychological development\r'),
(63, 'F90', 'F98', 5, 'Behavioural and emotional disorders with onset usually occurring in childhood and adolescence\r'),
(64, 'F99', 'F99', 5, 'Unspecified mental disorder\r'),
(65, 'G00', 'G09', 6, 'Inflammatory diseases of the central nervous system\r'),
(66, 'G10', 'G14', 6, 'Systemic atrophies primarily affecting the central nervous system\r'),
(67, 'G20', 'G26', 6, 'Extrapyramidal and movement disorders\r'),
(68, 'G30', 'G32', 6, 'Other degenerative diseases of the nervous system\r'),
(69, 'G35', 'G37', 6, 'Demyelinating diseases of the central nervous system\r'),
(70, 'G40', 'G47', 6, 'Episodic and paroxysmal disorders\r'),
(71, 'G50', 'G59', 6, 'Nerve, nerve root and plexus disorders\r'),
(72, 'G60', 'G64', 6, 'Polyneuropathies and other disorders of the peripheral nervous system\r'),
(73, 'G70', 'G73', 6, 'Diseases of myoneural junction and muscle\r'),
(74, 'G80', 'G83', 6, 'Cerebral palsy and other paralytic syndromes\r'),
(75, 'G90', 'G99', 6, 'Other disorders of the nervous system\r'),
(76, 'H00', 'H06', 7, 'Disorders of eyelid, lacrimal system and orbit\r'),
(77, 'H10', 'H13', 7, 'Disorders of conjunctiva\r'),
(78, 'H15', 'H22', 7, 'Disorders of sclera, cornea, iris and ciliary body\r'),
(79, 'H25', 'H28', 7, 'Disorders of lens\r'),
(80, 'H30', 'H36', 7, 'Disorders of choroid and retina\r'),
(81, 'H40', 'H42', 7, 'Glaucoma\r'),
(82, 'H43', 'H45', 7, 'Disorders of vitreous body and globe\r'),
(83, 'H46', 'H48', 7, 'Disorders of optic nerve and visual pathways\r'),
(84, 'H49', 'H52', 7, 'Disorders of ocular muscles, binocular movement, accommodation and refraction\r'),
(85, 'H53', 'H54', 7, 'Visual disturbances and blindness\r'),
(86, 'H55', 'H59', 7, 'Other disorders of eye and adnexa\r'),
(87, 'H60', 'H62', 8, 'Diseases of external ear\r'),
(88, 'H65', 'H75', 8, 'Diseases of middle ear and mastoid\r'),
(89, 'H80', 'H83', 8, 'Diseases of inner ear\r'),
(90, 'H90', 'H95', 8, 'Other disorders of ear\r'),
(91, 'I00', 'I02', 9, 'Acute rheumatic fever\r'),
(92, 'I05', 'I09', 9, 'Chronic rheumatic heart diseases\r'),
(93, 'I10', 'I15', 9, 'Hypertensive diseases\r'),
(94, 'I20', 'I25', 9, 'Ischaemic heart diseases\r'),
(95, 'I26', 'I28', 9, 'Pulmonary heart disease and diseases of pulmonary circulation\r'),
(96, 'I30', 'I52', 9, 'Other forms of heart disease\r'),
(97, 'I60', 'I69', 9, 'Cerebrovascular diseases\r'),
(98, 'I70', 'I79', 9, 'Diseases of arteries, arterioles and capillaries\r'),
(99, 'I80', 'I89', 9, 'Diseases of veins, lymphatic vessels and lymph nodes, not elsewhere classified\r'),
(100, 'I95', 'I99', 9, 'Other and unspecified disorders of the circulatory system\r'),
(101, 'J00', 'J06', 10, 'Acute upper respiratory infections\r'),
(102, 'J09', 'J18', 10, 'Influenza and pneumonia\r'),
(103, 'J20', 'J22', 10, 'Other acute lower respiratory infections\r'),
(104, 'J30', 'J39', 10, 'Other diseases of upper respiratory tract\r'),
(105, 'J40', 'J47', 10, 'Chronic lower respiratory diseases\r'),
(106, 'J60', 'J70', 10, 'Lung diseases due to external agents\r'),
(107, 'J80', 'J84', 10, 'Other respiratory diseases principally affecting the interstitium\r'),
(108, 'J85', 'J86', 10, 'Suppurative and necrotic conditions of lower respiratory tract\r'),
(109, 'J90', 'J94', 10, 'Other diseases of pleura\r'),
(110, 'J95', 'J99', 10, 'Other diseases of the respiratory system\r'),
(111, 'K00', 'K14', 11, 'Diseases of oral cavity, salivary glands and jaws\r'),
(112, 'K20', 'K31', 11, 'Diseases of oesophagus, stomach and duodenum\r'),
(113, 'K35', 'K38', 11, 'Diseases of appendix\r'),
(114, 'K40', 'K46', 11, 'Hernia\r'),
(115, 'K50', 'K52', 11, 'Noninfective enteritis and colitis\r'),
(116, 'K55', 'K64', 11, 'Other diseases of intestines\r'),
(117, 'K65', 'K67', 11, 'Diseases of peritoneum\r'),
(118, 'K70', 'K77', 11, 'Diseases of liver\r'),
(119, 'K80', 'K87', 11, 'Disorders of gallbladder, biliary tract and pancreas\r'),
(120, 'K90', 'K93', 11, 'Other diseases of the digestive system\r'),
(121, 'L00', 'L08', 12, 'Infections of the skin and subcutaneous tissue\r'),
(122, 'L10', 'L14', 12, 'Bullous disorders\r'),
(123, 'L20', 'L30', 12, 'Dermatitis and eczema\r'),
(124, 'L40', 'L45', 12, 'Papulosquamous disorders\r'),
(125, 'L50', 'L54', 12, 'Urticaria and erythema\r'),
(126, 'L55', 'L59', 12, 'Radiation-related disorders of the skin and subcutaneous tissue\r'),
(127, 'L60', 'L75', 12, 'Disorders of skin appendages\r'),
(128, 'L80', 'L99', 12, 'Other disorders of the skin and subcutaneous tissue\r'),
(129, 'M00', 'M03', 13, 'Infectious arthropathies\r'),
(130, 'M05', 'M14', 13, 'Inflammatory polyarthropathies\r'),
(131, 'M15', 'M19', 13, 'Arthrosis\r'),
(132, 'M20', 'M25', 13, 'Other joint disorders\r'),
(133, 'M30', 'M36', 13, 'Systemic connective tissue disorders\r'),
(134, 'M40', 'M43', 13, 'Deforming dorsopathies\r'),
(135, 'M45', 'M49', 13, 'Spondylopathies\r'),
(136, 'M50', 'M54', 13, 'Other dorsopathies\r'),
(137, 'M60', 'M63', 13, 'Disorders of muscles\r'),
(138, 'M65', 'M68', 13, 'Disorders of synovium and tendon\r'),
(139, 'M70', 'M79', 13, 'Other soft tissue disorders\r'),
(140, 'M80', 'M85', 13, 'Disorders of bone density and structure\r'),
(141, 'M86', 'M90', 13, 'Other osteopathies\r'),
(142, 'M91', 'M94', 13, 'Chondropathies\r'),
(143, 'M95', 'M99', 13, 'Other disorders of the musculoskeletal system and connective tissue\r'),
(144, 'N00', 'N08', 14, 'Glomerular diseases\r'),
(145, 'N10', 'N16', 14, 'Renal tubulo-interstitial diseases\r'),
(146, 'N17', 'N19', 14, 'Renal failure\r'),
(147, 'N20', 'N23', 14, 'Urolithiasis\r'),
(148, 'N25', 'N29', 14, 'Other disorders of kidney and ureter\r'),
(149, 'N30', 'N39', 14, 'Other diseases of urinary system\r'),
(150, 'N40', 'N51', 14, 'Diseases of male genital organs\r'),
(151, 'N60', 'N64', 14, 'Disorders of breast\r'),
(152, 'N70', 'N77', 14, 'Inflammatory diseases of female pelvic organs\r'),
(153, 'N80', 'N98', 14, 'Noninflammatory disorders of female genital tract\r'),
(154, 'N99', 'N99', 14, 'Other disorders of the genitourinary system\r'),
(155, 'O00', 'O08', 15, 'Pregnancy with abortive outcome\r'),
(156, 'O10', 'O16', 15, 'Oedema, proteinuria and hypertensive disorders in pregnancy, childbirth and the puerperium\r'),
(157, 'O20', 'O29', 15, 'Other maternal disorders predominantly related to pregnancy\r'),
(158, 'O30', 'O48', 15, 'Maternal care related to the fetus and amniotic cavity and possible delivery problems\r'),
(159, 'O60', 'O75', 15, 'Complications of labour and delivery\r'),
(160, 'O80', 'O84', 15, 'Delivery\r'),
(161, 'O85', 'O92', 15, 'Complications predominantly related to the puerperium\r'),
(162, 'O94', 'O99', 15, 'Other obstetric conditions, not elsewhere classified\r'),
(163, 'P00', 'P04', 16, 'Fetus and newborn affected by maternal factors and by complications of pregnancy, labour and delivery\r'),
(164, 'P05', 'P08', 16, 'Disorders related to length of gestation and fetal growth\r'),
(165, 'P10', 'P15', 16, 'Birth trauma\r'),
(166, 'P20', 'P29', 16, 'Respiratory and cardiovascular disorders specific to the perinatal period\r'),
(167, 'P35', 'P39', 16, 'Infections specific to the perinatal period\r'),
(168, 'P50', 'P61', 16, 'Haemorrhagic and haematological disorders of fetus and newborn\r'),
(169, 'P70', 'P74', 16, 'Transitory endocrine and metabolic disorders specific to fetus and newborn\r'),
(170, 'P75', 'P78', 16, 'Digestive system disorders of fetus and newborn\r'),
(171, 'P80', 'P83', 16, 'Conditions involving the integument and temperature regulation of fetus and newborn\r'),
(172, 'P90', 'P96', 16, 'Other disorders originating in the perinatal period\r'),
(173, 'Q00', 'Q07', 17, 'Congenital malformations of the nervous system\r'),
(174, 'Q10', 'Q18', 17, 'Congenital malformations of eye, ear, face and neck\r'),
(175, 'Q20', 'Q28', 17, 'Congenital malformations of the circulatory system\r'),
(176, 'Q30', 'Q34', 17, 'Congenital malformations of the respiratory system\r'),
(177, 'Q35', 'Q37', 17, 'Cleft lip and cleft palate\r'),
(178, 'Q38', 'Q45', 17, 'Other congenital malformations of the digestive system\r'),
(179, 'Q50', 'Q56', 17, 'Congenital malformations of genital organs\r'),
(180, 'Q60', 'Q64', 17, 'Congenital malformations of the urinary system\r'),
(181, 'Q65', 'Q79', 17, 'Congenital malformations and deformations of the musculoskeletal system\r'),
(182, 'Q80', 'Q89', 17, 'Other congenital malformations\r'),
(183, 'Q90', 'Q99', 17, 'Chromosomal abnormalities, not elsewhere classified\r'),
(184, 'R00', 'R09', 18, 'Symptoms and signs involving the circulatory and respiratory systems\r'),
(185, 'R10', 'R19', 18, 'Symptoms and signs involving the digestive system and abdomen\r'),
(186, 'R20', 'R23', 18, 'Symptoms and signs involving the skin and subcutaneous tissue\r'),
(187, 'R25', 'R29', 18, 'Symptoms and signs involving the nervous and musculoskeletal systems\r'),
(188, 'R30', 'R39', 18, 'Symptoms and signs involving the urinary system\r'),
(189, 'R40', 'R46', 18, 'Symptoms and signs involving cognition, perception, emotional state and behaviour\r'),
(190, 'R47', 'R49', 18, 'Symptoms and signs involving speech and voice\r'),
(191, 'R50', 'R69', 18, 'General symptoms and signs\r'),
(192, 'R70', 'R79', 18, 'Abnormal findings on examination of blood, without diagnosis\r'),
(193, 'R80', 'R82', 18, 'Abnormal findings on examination of urine, without diagnosis\r'),
(194, 'R83', 'R89', 18, 'Abnormal findings on examination of other body fluids, substances and tissues, without diagnosis\r'),
(195, 'R90', 'R94', 18, 'Abnormal findings on diagnostic imaging and in function studies, without diagnosis\r'),
(196, 'R95', 'R99', 18, 'Ill-defined and unknown causes of mortality\r'),
(197, 'S00', 'S09', 19, 'Injuries to the head\r'),
(198, 'S10', 'S19', 19, 'Injuries to the neck\r'),
(199, 'S20', 'S29', 19, 'Injuries to the thorax\r'),
(200, 'S30', 'S39', 19, 'Injuries to the abdomen, lower back, lumbar spine and pelvis\r'),
(201, 'S40', 'S49', 19, 'Injuries to the shoulder and upper arm\r'),
(202, 'S50', 'S59', 19, 'Injuries to the elbow and forearm\r'),
(203, 'S60', 'S69', 19, 'Injuries to the wrist and hand\r'),
(204, 'S70', 'S79', 19, 'Injuries to the hip and thigh\r'),
(205, 'S80', 'S89', 19, 'Injuries to the knee and lower leg\r'),
(206, 'S90', 'S99', 19, 'Injuries to the ankle and foot\r'),
(207, 'T00', 'T07', 19, 'Injuries involving multiple body regions\r'),
(208, 'T08', 'T14', 19, 'Injuries to unspecified part of trunk, limb or body region\r'),
(209, 'T15', 'T19', 19, 'Effects of foreign body entering through natural orifice\r'),
(210, 'T20', 'T25', 19, 'Burns and corrosions of external body surface, specified by site\r'),
(211, 'T26', 'T28', 19, 'Burns and corrosions confined to eye and internal organs\r'),
(212, 'T29', 'T32', 19, 'Burns and corrosions of multiple and unspecified body regions\r'),
(213, 'T33', 'T35', 19, 'Frostbite\r'),
(214, 'T36', 'T50', 19, 'Poisoning by drugs, medicaments and biological substances\r'),
(215, 'T51', 'T65', 19, 'Toxic effects of substances chiefly nonmedicinal as to source\r'),
(216, 'T66', 'T78', 19, 'Other and unspecified effects of external causes\r'),
(217, 'T79', 'T79', 19, 'Certain early complications of trauma\r'),
(218, 'T80', 'T88', 19, 'Complications of surgical and medical care, not elsewhere classified\r'),
(219, 'T90', 'T98', 19, 'Sequelae of injuries, of poisoning and of other consequences of external causes\r'),
(220, 'V01', 'V09', 20, 'Pedestrian injured in transport accident\r'),
(221, 'V10', 'V19', 20, 'Pedal cyclist injured in transport accident\r'),
(222, 'V20', 'V29', 20, 'Motorcycle rider injured in transport accident\r'),
(223, 'V30', 'V39', 20, 'Occupant of three-wheeled motor vehicle injured in transport accident\r'),
(224, 'V40', 'V49', 20, 'Car occupant injured in transport accident\r'),
(225, 'V50', 'V59', 20, 'Occupant of pick-up truck or van injured in transport accident\r'),
(226, 'V60', 'V69', 20, 'Occupant of heavy transport vehicle injured in transport accident\r'),
(227, 'V70', 'V79', 20, 'Bus occupant injured in transport accident\r'),
(228, 'V80', 'V89', 20, 'Other land transport accidents\r'),
(229, 'V90', 'V94', 20, 'Water transport accidents\r'),
(230, 'V95', 'V97', 20, 'Air and space transport accidents\r'),
(231, 'V98', 'V99', 20, 'Other and unspecified transport accidents\r'),
(232, 'W00', 'W19', 20, 'Falls\r'),
(233, 'W20', 'W49', 20, 'Exposure to inanimate mechanical forces\r'),
(234, 'W50', 'W64', 20, 'Exposure to animate mechanical forces\r'),
(235, 'W65', 'W74', 20, 'Accidental drowning and submersion\r'),
(236, 'W75', 'W84', 20, 'Other accidental threats to breathing\r'),
(237, 'W85', 'W99', 20, 'Exposure to electric current, radiation and extreme ambient air temperature and pressure\r'),
(238, 'X00', 'X09', 20, 'Exposure to smoke, fire and flames\r'),
(239, 'X10', 'X19', 20, 'Contact with heat and hot substances\r'),
(240, 'X20', 'X29', 20, 'Contact with venomous animals and plants\r'),
(241, 'X30', 'X39', 20, 'Exposure to forces of nature\r'),
(242, 'X40', 'X49', 20, 'Accidental poisoning by and exposure to noxious substances\r'),
(243, 'X50', 'X57', 20, 'Overexertion, travel and privation\r'),
(244, 'X58', 'X59', 20, 'Accidental exposure to other and unspecified factors\r'),
(245, 'X60', 'X84', 20, 'Intentional self-harm\r'),
(246, 'X85', 'Y09', 20, 'Assault\r'),
(247, 'Y10', 'Y34', 20, 'Event of undetermined intent\r'),
(248, 'Y35', 'Y36', 20, 'Legal intervention and operations of war\r'),
(249, 'Y40', 'Y59', 20, 'Drugs, medicaments and biological substances causing adverse effects in therapeutic use\r'),
(250, 'Y60', 'Y69', 20, 'Misadventures to patients during surgical and medical care\r'),
(251, 'Y70', 'Y82', 20, 'Medical devices associated with adverse incidents in diagnostic and therapeutic use\r'),
(252, 'Y83', 'Y84', 20, 'Surgical and other medical procedures as the cause of abnormal reaction of the patient, or of later complication, without mention of misadventure at the time of the procedure\r'),
(253, 'Y85', 'Y89', 20, 'Sequelae of external causes of morbidity and mortality\r'),
(254, 'Y90', 'Y98', 20, 'Supplementary factors related to causes of morbidity and mortality classified elsewhere\r'),
(255, 'Z00', 'Z13', 21, 'Persons encountering health services for examination and investigation\r'),
(256, 'Z20', 'Z29', 21, 'Persons with potential health hazards related to communicable diseases\r'),
(257, 'Z30', 'Z39', 21, 'Persons encountering health services in circumstances related to reproduction\r'),
(258, 'Z40', 'Z54', 21, 'Persons encountering health services for specific procedures and health care\r'),
(259, 'Z55', 'Z65', 21, 'Persons with potential health hazards related to socioeconomic and psychosocial circumstances\r'),
(260, 'Z70', 'Z76', 21, 'Persons encountering health services in other circumstances\r'),
(261, 'Z80', 'Z99', 21, 'Persons with potential health hazards related to family and personal history and certain conditions influencing health status\r'),
(262, 'U00', 'U49', 22, 'Provisional assignment of new diseases of uncertain etiology or emergency use\r'),
(263, 'U82', 'U85', 22, 'Resistance to antimicrobial and antineoplastic drugs\r');

-- --------------------------------------------------------

--
-- Struktur dari tabel `obat`
--

CREATE TABLE `obat` (
  `id_obat` int(11) NOT NULL,
  `nama_obat` varchar(250) NOT NULL,
  `jumlah_obat` int(10) DEFAULT NULL,
  `expired_date` date NOT NULL,
  `jenis_obat` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `obat`
--

INSERT INTO `obat` (`id_obat`, `nama_obat`, `jumlah_obat`, `expired_date`, `jenis_obat`) VALUES
(36, 'Antimo', 106, '2022-07-31', 'Kapsul'),
(37, 'konidin', 50, '2022-08-05', 'Kapsul'),
(38, 'gpu', 0, '2022-03-12', 'Tablet'),
(39, 'gazero', 77, '2022-12-22', 'Tablet');

-- --------------------------------------------------------

--
-- Struktur dari tabel `pasien`
--

CREATE TABLE `pasien` (
  `id_pasien` int(11) NOT NULL,
  `no_bpjs` varchar(50) DEFAULT NULL,
  `nama` varchar(250) NOT NULL,
  `no_rm` varchar(50) NOT NULL,
  `tanggal_lahir` date NOT NULL,
  `jenis_kelamin` varchar(20) NOT NULL,
  `nik` varchar(50) DEFAULT NULL,
  `no_telfone` varchar(20) NOT NULL,
  `alamat` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `pasien`
--

INSERT INTO `pasien` (`id_pasien`, `no_bpjs`, `nama`, `no_rm`, `tanggal_lahir`, `jenis_kelamin`, `nik`, `no_telfone`, `alamat`) VALUES
(9, '343734635345', 'Yerico alis Nyambek', '454', '1999-02-12', 'Laki Laki', '5643653542353564', '0987766554432', 'wangkalkepuh'),
(11, '132343453426', 'alan alis ayub', '453', '1999-02-12', 'Laki Laki', '5362524132412353', '12321335465', 'japanan'),
(12, '453492347284', 'alann alis ayub', '656', '1998-05-04', 'Laki Laki', '5242645978456968', '090695768564', 'tanggungan'),
(13, '796756576846', 'anton', '5646', '1989-12-31', 'Laki Laki', '5646746635645747', '07456346457', 'mejoylosari'),
(14, '489574872384', 'antonio konte', '6868', '2000-02-12', 'Laki Laki', '9646696674656756', '54568345945734', 'sukoiber'),
(15, '456456728472', 'nyambek gaming', '75747', '1944-04-04', 'Laki Laki', '8553543534353463', '23436586745534', 'sepanyul'),
(16, '-', 'nyimbek', '2314', '1999-02-23', 'Laki Laki', '4624513426576478', '534543646745', 'kedungturi'),
(17, '-', 'Nyambek Ngentoy', '242345', '2025-02-01', 'Perempuan', '4444444444444444', '43545423525235', 'gempol legundi'),
(18, '666666666666', 'Ayub KUNTUL', '6576', '2066-06-06', 'Laki Laki', '-', '342414', 'sukopingir'),
(19, '777777777777', 'Antonnnnnnn', '232342', '2007-07-07', 'Laki Laki', '-', '23242323241234', 'blimbing'),
(21, '-', 'paud', '666', '2016-03-26', 'Perempuan', '-', '4567434573', 'menganti');

-- --------------------------------------------------------

--
-- Struktur dari tabel `pembelian`
--

CREATE TABLE `pembelian` (
  `id_pembelian` int(11) NOT NULL,
  `jumlah` int(10) NOT NULL,
  `tanggal_beli` date NOT NULL,
  `expired_date` date NOT NULL,
  `id_obat` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `pembelian`
--

INSERT INTO `pembelian` (`id_pembelian`, `jumlah`, `tanggal_beli`, `expired_date`, `id_obat`) VALUES
(57, 50, '2022-02-23', '2022-03-04', 36),
(58, 30, '2022-02-23', '2022-03-05', 36),
(59, 20, '2022-02-23', '2022-02-28', 37),
(60, 15, '2022-02-23', '2022-03-12', 38),
(61, 50, '2022-02-23', '2022-07-31', 36),
(62, 50, '2022-02-23', '2022-08-05', 37),
(63, 80, '2022-02-25', '2022-12-22', 39);

--
-- Trigger `pembelian`
--
DELIMITER $$
CREATE TRIGGER `pembelian_produk_update` AFTER INSERT ON `pembelian` FOR EACH ROW BEGIN
	UPDATE obat
    SET jumlah_obat = jumlah_obat + new.jumlah ,
    expired_date = new.expired_date
    WHERE id_obat = new.id_obat;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Struktur dari tabel `pendaftaran`
--

CREATE TABLE `pendaftaran` (
  `id_pendaftaran` int(11) NOT NULL,
  `nama_dokter` varchar(250) NOT NULL,
  `tindakan` varchar(250) NOT NULL,
  `status` varchar(5) NOT NULL,
  `tanggal_daftar` date NOT NULL,
  `keterangan` varchar(10) NOT NULL,
  `id_pasien` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `pendaftaran`
--

INSERT INTO `pendaftaran` (`id_pendaftaran`, `nama_dokter`, `tindakan`, `status`, `tanggal_daftar`, `keterangan`, `id_pasien`) VALUES
(18, 'dr. Yohanes Ary Prayoga', 'PCR', '0', '2022-02-10', 'BPJS', 15),
(19, 'dr. Yohanes Ary Prayoga', 'KIA', '0', '2022-02-10', 'BPJS', 14),
(20, 'dr. Yudha Erik Prabowo', 'Poli Kecantikan', '0', '2022-02-13', 'BPJS', 11),
(21, 'dr. Yohanes Ary Prayoga', 'PCR', '0', '2022-02-13', 'BPJS', 14),
(22, 'dr. Yohanes Ary Prayoga', 'Rawat Luka', '0', '2022-02-13', 'BPJS', 14),
(23, 'dr. Yudha Erik Prabowo', 'Antigen', '0', '2022-02-13', 'BPJS', 11),
(24, 'dr. Yohanes Ary Prayoga', 'KIA', '0', '2022-02-13', 'BPJS', 14),
(25, 'dr. Yohanes Ary Prayoga', 'Poli Kecantikan', '0', '2022-02-13', 'BPJS', 15),
(26, 'dr. Yudha Erik Prabowo', 'Fisioterapi', '0', '2022-02-13', 'BPJS', 11),
(27, 'dr. Yohanes Ary Prayoga', 'KIA', '0', '2022-02-13', 'BPJS', 12),
(28, 'dr. Yohanes Ary Prayoga', 'Poli Umum', '0', '2022-02-13', 'BPJS', 15),
(29, 'dr. Yudha Erik Prabowo', 'Poli Kecantikan', '0', '2022-02-16', 'BPJS', 11),
(33, 'dr. Yohanes Ary Prayoga', 'Poli Umum', '0', '2022-02-17', 'BPJS', 11),
(38, 'dr. Yudha Erik Prabowo', 'Poli Umum', '0', '2022-02-18', 'BPJS', 18),
(39, 'dr. Yohanes Ary Prayoga', 'Poli Kecantikan', '0', '2022-02-18', 'Umum', 17),
(40, 'dr. Yohanes Ary Prayoga', 'Fisioterapi', '0', '2022-02-18', 'BPJS', 19),
(41, 'dr. Yohanes Ary Prayoga', 'Poli Umum', '0', '2022-02-19', 'BPJS', 14),
(42, 'dr. Yohanes Ary Prayoga', 'Poli Kecantikan', '0', '2022-02-20', 'BPJS', 9),
(43, 'dr. Yohanes Ary Prayoga', 'Fisioterapi', '0', '2022-02-23', 'BPJS', 9),
(44, 'dr. Yudha Erik Prabowo', 'Fisioterapi', '0', '2022-02-23', 'Umum', 16),
(45, 'dr. Yudha Erik Prabowo', 'Poli Kecantikan', '0', '2022-02-23', 'BPJS', 11),
(46, 'dr. Yohanes Ary Prayoga', 'Antigen', '0', '2022-02-23', 'Umum', 13),
(47, 'dr. Yudha Erik Prabowo', 'Fisioterapi', '0', '2022-02-23', 'BPJS', 15),
(49, 'dr. Yohanes Ary Prayoga', 'Poli Umum', '0', '2022-02-25', 'BPJS', 11),
(50, 'dr. Yohanes Ary Prayoga', 'Poli Kecantikan', '0', '2022-02-26', 'BPJS', 9),
(51, 'dr. Yudha Erik Prabowo', 'Fisioterapi', '0', '2022-02-26', 'BPJS', 15),
(52, 'dr. Yohanes Ary Prayoga', 'Poli Umum', '0', '2022-02-26', 'BPJS', 14),
(53, 'dr. Yohanes Ary Prayoga', 'Poli Umum', '0', '2022-02-26', 'Umum', 11),
(55, 'dr. Yudha Erik Prabowo', 'Poli Kecantikan', '0', '2022-02-26', 'Umum', 21),
(56, 'dr. Yohanes Ary Prayoga', 'Poli Umum', '0', '2022-02-26', 'BPJS', 14),
(57, 'dr. Yohanes Ary Prayoga', 'Poli Umum', '0', '2022-02-26', 'BPJS', 14),
(58, 'dr. Yohanes Ary Prayoga', 'Poli Umum', '0', '2022-02-27', 'Umum', 15);

-- --------------------------------------------------------

--
-- Struktur dari tabel `penjualan`
--

CREATE TABLE `penjualan` (
  `id_penjualan` int(11) NOT NULL,
  `jumlah` int(11) NOT NULL,
  `tanggal_terjual` date NOT NULL,
  `id_pendaftaran` int(11) NOT NULL,
  `id_obat` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `penjualan`
--

INSERT INTO `penjualan` (`id_penjualan`, `jumlah`, `tanggal_terjual`, `id_pendaftaran`, `id_obat`) VALUES
(37, 5, '2022-02-23', 41, 36),
(38, 3, '2022-02-23', 42, 38),
(39, 4, '2022-02-23', 43, 36),
(40, 3, '2022-02-23', 43, 37),
(41, 2, '2022-02-23', 44, 36),
(42, 2, '2022-02-23', 44, 36),
(43, 4, '2022-02-23', 44, 37),
(44, 4, '2022-02-23', 44, 37),
(45, 1, '2022-02-23', 44, 38),
(46, 1, '2022-02-23', 44, 38),
(47, 2, '2022-02-23', 45, 38),
(48, 2, '2022-02-23', 45, 36),
(49, 1, '2022-02-26', 49, 36),
(50, 2, '2022-02-26', 49, 36),
(51, 3, '2022-02-26', 46, 37),
(52, 2, '2022-02-26', 46, 38),
(53, 3, '2022-02-26', 46, 36),
(54, 3, '2022-02-26', 47, 36),
(55, 4, '2022-02-26', 47, 38),
(56, 3, '2022-02-26', 51, 37),
(57, 2, '2022-02-26', 52, 38),
(58, 3, '2022-02-26', 55, 37),
(59, 3, '2022-02-26', 55, 36),
(60, 2, '2022-02-27', 57, 36),
(61, 3, '2022-02-27', 58, 39);

--
-- Trigger `penjualan`
--
DELIMITER $$
CREATE TRIGGER `penjualan_produk_update` AFTER INSERT ON `penjualan` FOR EACH ROW BEGIN
	UPDATE obat
    SET jumlah_obat = jumlah_obat - new.jumlah
    WHERE id_obat = new.id_obat;
END
$$
DELIMITER ;

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `diagnosa`
--
ALTER TABLE `diagnosa`
  ADD PRIMARY KEY (`id_diagnosa`),
  ADD KEY `id_pendaftaran` (`id_pendaftaran`),
  ADD KEY `id_icd` (`id_icd`);

--
-- Indeks untuk tabel `icd_10`
--
ALTER TABLE `icd_10`
  ADD PRIMARY KEY (`id_icd`);

--
-- Indeks untuk tabel `obat`
--
ALTER TABLE `obat`
  ADD PRIMARY KEY (`id_obat`);

--
-- Indeks untuk tabel `pasien`
--
ALTER TABLE `pasien`
  ADD PRIMARY KEY (`id_pasien`);

--
-- Indeks untuk tabel `pembelian`
--
ALTER TABLE `pembelian`
  ADD PRIMARY KEY (`id_pembelian`),
  ADD KEY `id_obat` (`id_obat`);

--
-- Indeks untuk tabel `pendaftaran`
--
ALTER TABLE `pendaftaran`
  ADD PRIMARY KEY (`id_pendaftaran`),
  ADD KEY `id_pasien` (`id_pasien`);

--
-- Indeks untuk tabel `penjualan`
--
ALTER TABLE `penjualan`
  ADD PRIMARY KEY (`id_penjualan`),
  ADD KEY `id_pendaftaran` (`id_pendaftaran`),
  ADD KEY `id_obat` (`id_obat`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `diagnosa`
--
ALTER TABLE `diagnosa`
  MODIFY `id_diagnosa` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=131;

--
-- AUTO_INCREMENT untuk tabel `icd_10`
--
ALTER TABLE `icd_10`
  MODIFY `id_icd` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=266;

--
-- AUTO_INCREMENT untuk tabel `obat`
--
ALTER TABLE `obat`
  MODIFY `id_obat` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=40;

--
-- AUTO_INCREMENT untuk tabel `pasien`
--
ALTER TABLE `pasien`
  MODIFY `id_pasien` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT untuk tabel `pembelian`
--
ALTER TABLE `pembelian`
  MODIFY `id_pembelian` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=64;

--
-- AUTO_INCREMENT untuk tabel `pendaftaran`
--
ALTER TABLE `pendaftaran`
  MODIFY `id_pendaftaran` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=59;

--
-- AUTO_INCREMENT untuk tabel `penjualan`
--
ALTER TABLE `penjualan`
  MODIFY `id_penjualan` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=62;

--
-- Ketidakleluasaan untuk tabel pelimpahan (Dumped Tables)
--

--
-- Ketidakleluasaan untuk tabel `diagnosa`
--
ALTER TABLE `diagnosa`
  ADD CONSTRAINT `diagnosa_ibfk_1` FOREIGN KEY (`id_pendaftaran`) REFERENCES `pendaftaran` (`id_pendaftaran`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `diagnosa_ibfk_2` FOREIGN KEY (`id_icd`) REFERENCES `icd_10` (`id_icd`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Ketidakleluasaan untuk tabel `pembelian`
--
ALTER TABLE `pembelian`
  ADD CONSTRAINT `pembelian_ibfk_1` FOREIGN KEY (`id_obat`) REFERENCES `obat` (`id_obat`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Ketidakleluasaan untuk tabel `pendaftaran`
--
ALTER TABLE `pendaftaran`
  ADD CONSTRAINT `pendaftaran_ibfk_1` FOREIGN KEY (`id_pasien`) REFERENCES `pasien` (`id_pasien`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Ketidakleluasaan untuk tabel `penjualan`
--
ALTER TABLE `penjualan`
  ADD CONSTRAINT `penjualan_ibfk_1` FOREIGN KEY (`id_obat`) REFERENCES `obat` (`id_obat`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `penjualan_ibfk_2` FOREIGN KEY (`id_pendaftaran`) REFERENCES `pendaftaran` (`id_pendaftaran`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
