<?php  
    date_default_timezone_set('Asia/Jakarta');
    echo $timestamp = date("d-m-Y H:i:s");
?>